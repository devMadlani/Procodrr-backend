import express from "express";
import data from "./courses.json" with { type: "json" };
import cors from "cors";

const app = express();
app.use(
  cors({
    origin: "http://localhost:5173",
    credentials: true,
  })
);

app.get("/", (req, res) => {
  res.json(data);
});

app.listen(4000, () => {
  console.log("Server started");
});
